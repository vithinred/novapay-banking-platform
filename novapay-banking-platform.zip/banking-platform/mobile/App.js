import React, { useState } from 'react'
import { NavigationContainer } from '@react-navigation/native'
import { createNativeStackNavigator } from '@react-navigation/native-stack'
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs'
import { SafeAreaProvider } from 'react-native-safe-area-context'
import { Text } from 'react-native'
import { StatusBar } from 'expo-status-bar'

import OnboardingScreen from './src/screens/OnboardingScreen'
import DashboardScreen  from './src/screens/DashboardScreen'
import TransfersScreen  from './src/screens/TransfersScreen'
import BillPayScreen    from './src/screens/BillPayScreen'
import { COLORS } from './src/styles/theme'

const Stack = createNativeStackNavigator()
const Tab   = createBottomTabNavigator()

function TabIcon({ name, focused }) {
  const icons = { Dashboard: '⬡', Transfers: '⇄', 'Bill Pay': '◈' }
  return (
    <Text style={{ fontSize: 18, color: focused ? COLORS.accent : COLORS.textMuted }}>
      {icons[name]}
    </Text>
  )
}

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarIcon: ({ focused }) => <TabIcon name={route.name} focused={focused} />,
        tabBarLabel: ({ focused }) => (
          <Text style={{ fontSize: 10, color: focused ? COLORS.accent : COLORS.textMuted, marginBottom: 4 }}>
            {route.name}
          </Text>
        ),
        tabBarStyle: {
          backgroundColor: COLORS.bgCard,
          borderTopColor: COLORS.border,
          borderTopWidth: 1,
          height: 64,
          paddingTop: 8,
        },
        tabBarBackground: () => null,
      })}
    >
      <Tab.Screen name="Dashboard"  component={DashboardScreen} />
      <Tab.Screen name="Transfers"  component={TransfersScreen} />
      <Tab.Screen name="Bill Pay"   component={BillPayScreen} />
    </Tab.Navigator>
  )
}

export default function App() {
  const [onboarded, setOnboarded] = useState(false)

  return (
    <SafeAreaProvider>
      <StatusBar style="light" />
      <NavigationContainer>
        <Stack.Navigator screenOptions={{ headerShown: false }}>
          {!onboarded ? (
            <Stack.Screen name="Onboarding">
              {props => <OnboardingScreen {...props} onComplete={() => setOnboarded(true)} />}
            </Stack.Screen>
          ) : (
            <Stack.Screen name="Main" component={MainTabs} />
          )}
        </Stack.Navigator>
      </NavigationContainer>
    </SafeAreaProvider>
  )
}
