import React, { useState } from 'react'
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Animated } from 'react-native'
import { useSafeAreaInsets } from 'react-native-safe-area-context'
import { COLORS, RADIUS } from '../styles/theme'

const BILLERS = [
  { id: 1, name: 'AT&T Wireless',    category: 'Utilities',    due: 'Feb 3',  amount: 89.99,   icon: '📡', status: 'due' },
  { id: 2, name: 'TXU Electricity',  category: 'Utilities',    due: 'Feb 7',  amount: 134.50,  icon: '⚡', status: 'due' },
  { id: 3, name: 'Oakwood Rent',     category: 'Housing',      due: 'Feb 1',  amount: 1450.00, icon: '🏠', status: 'scheduled' },
  { id: 4, name: 'Chase Visa',       category: 'Credit Card',  due: 'Feb 15', amount: 342.00,  icon: '💳', status: 'pending' },
  { id: 5, name: 'Spotify',          category: 'Subscription', due: 'Feb 18', amount: 9.99,    icon: '♪',  status: 'autopay' },
  { id: 6, name: 'Xfinity Internet', category: 'Utilities',    due: 'Feb 20', amount: 65.00,   icon: '◈',  status: 'autopay' },
]

const STATUS = {
  due:       { label: 'Due Soon',  color: '#FFB547' },
  scheduled: { label: 'Scheduled', color: COLORS.accent },
  pending:   { label: 'Pending',   color: COLORS.textSecondary },
  autopay:   { label: 'AutoPay ✓', color: COLORS.success },
}

export default function BillPayScreen() {
  const insets = useSafeAreaInsets()
  const [paid,     setPaid]     = useState([])
  const [selected, setSelected] = useState(null)
  const [filter,   setFilter]   = useState('all')

  const handlePay = (id) => { setPaid(p => [...p, id]); setSelected(null) }

  const totalDue = BILLERS
    .filter(b => b.status === 'due' && !paid.includes(b.id))
    .reduce((s, b) => s + b.amount, 0)

  const visible = BILLERS.filter(b =>
    filter === 'all' ? true :
    filter === 'due' ? b.status === 'due' :
    b.status === 'autopay'
  )

  return (
    <ScrollView
      style={[styles.container, { paddingTop: insets.top + 16 }]}
      contentContainerStyle={styles.content}
    >
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>Bill Pay</Text>
        <View style={styles.totalCard}>
          <Text style={styles.totalLabel}>Outstanding</Text>
          <Text style={styles.totalAmt}>${totalDue.toFixed(2)}</Text>
        </View>
      </View>

      {/* Filters */}
      <View style={styles.filters}>
        {[['all', 'All'], ['due', 'Due Soon'], ['auto', 'AutoPay']].map(([key, label]) => (
          <TouchableOpacity
            key={key}
            style={[styles.filterBtn, filter === key && styles.filterActive]}
            onPress={() => setFilter(key)}
          >
            <Text style={[styles.filterText, filter === key && styles.filterTextActive]}>{label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Bill list */}
      {visible.map(bill => {
        const isPaid = paid.includes(bill.id)
        const meta = STATUS[bill.status]
        const isExpanded = selected === bill.id && !isPaid

        return (
          <TouchableOpacity
            key={bill.id}
            style={[styles.billCard, isExpanded && styles.billExpanded, isPaid && styles.billPaid]}
            onPress={() => !isPaid && setSelected(selected === bill.id ? null : bill.id)}
            activeOpacity={0.85}
          >
            <View style={styles.billRow}>
              <View style={styles.billIcon}><Text style={{ fontSize: 18 }}>{bill.icon}</Text></View>
              <View style={styles.billInfo}>
                <Text style={styles.billName}>{bill.name}</Text>
                <Text style={styles.billMeta}>{bill.category} · Due {bill.due}</Text>
              </View>
              <View style={styles.billRight}>
                <Text style={styles.billAmt}>${bill.amount.toFixed(2)}</Text>
                <Text style={[styles.billStatus, { color: isPaid ? COLORS.success : meta.color }]}>
                  {isPaid ? 'Paid ✓' : meta.label}
                </Text>
              </View>
            </View>

            {isExpanded && (
              <View style={styles.payPanel}>
                <View style={styles.payInfo}>
                  <Text style={styles.payLabel}>Pay to {bill.name}</Text>
                  <Text style={styles.payAmt}>${bill.amount.toFixed(2)}</Text>
                </View>
                <View style={styles.payBtns}>
                  <TouchableOpacity style={styles.payNow} onPress={() => handlePay(bill.id)}>
                    <Text style={styles.payNowText}>Pay Now</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={styles.schedule}>
                    <Text style={styles.scheduleText}>Schedule</Text>
                  </TouchableOpacity>
                </View>
              </View>
            )}
          </TouchableOpacity>
        )
      })}

      {/* Pay all due */}
      <TouchableOpacity
        style={styles.payAllBtn}
        onPress={() => visible.filter(b => b.status === 'due').forEach(b => handlePay(b.id))}
      >
        <Text style={styles.payAllText}>Pay All Due Bills</Text>
      </TouchableOpacity>
    </ScrollView>
  )
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.bgBase },
  content: { padding: 20, paddingBottom: 40, gap: 14 },

  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  title: { fontSize: 26, fontWeight: '700', color: COLORS.textPrimary },
  totalCard: { backgroundColor: COLORS.bgCard, borderRadius: RADIUS.md, padding: 12, borderWidth: 1, borderColor: COLORS.border, alignItems: 'flex-end' },
  totalLabel: { fontSize: 10, color: COLORS.textMuted, textTransform: 'uppercase', letterSpacing: 0.7 },
  totalAmt: { fontSize: 20, fontWeight: '700', color: '#FFB547' },

  filters: { flexDirection: 'row', gap: 8 },
  filterBtn: { paddingVertical: 7, paddingHorizontal: 14, backgroundColor: COLORS.bgCard, borderRadius: 100, borderWidth: 1, borderColor: COLORS.border },
  filterActive: { backgroundColor: COLORS.accentDim, borderColor: COLORS.accent },
  filterText: { fontSize: 12, color: COLORS.textSecondary, fontWeight: '500' },
  filterTextActive: { color: COLORS.accent },

  billCard: { backgroundColor: COLORS.bgCard, borderRadius: RADIUS.md, borderWidth: 1, borderColor: COLORS.border, overflow: 'hidden' },
  billExpanded: { borderColor: COLORS.accent },
  billPaid: { opacity: 0.45 },

  billRow: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14 },
  billIcon: { width: 40, height: 40, backgroundColor: COLORS.bgElevated, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  billInfo: { flex: 1, gap: 3 },
  billName: { fontSize: 14, fontWeight: '600', color: COLORS.textPrimary },
  billMeta: { fontSize: 11, color: COLORS.textMuted },
  billRight: { alignItems: 'flex-end', gap: 4 },
  billAmt: { fontSize: 15, fontWeight: '700', color: COLORS.textPrimary },
  billStatus: { fontSize: 10, fontWeight: '600' },

  payPanel: { padding: 14, paddingTop: 0, gap: 12 },
  payInfo: { flexDirection: 'row', justifyContent: 'space-between', paddingTop: 12, borderTopWidth: 1, borderTopColor: COLORS.border },
  payLabel: { fontSize: 13, color: COLORS.textSecondary },
  payAmt: { fontSize: 15, fontWeight: '700', color: COLORS.textPrimary },
  payBtns: { flexDirection: 'row', gap: 10 },
  payNow: { flex: 1, backgroundColor: COLORS.accent, borderRadius: RADIUS.sm, padding: 11, alignItems: 'center' },
  payNowText: { color: COLORS.bgBase, fontSize: 13, fontWeight: '700' },
  schedule: { flex: 1, backgroundColor: COLORS.bgElevated, borderRadius: RADIUS.sm, padding: 11, alignItems: 'center', borderWidth: 1, borderColor: COLORS.border },
  scheduleText: { color: COLORS.textSecondary, fontSize: 13, fontWeight: '500' },

  payAllBtn: { borderWidth: 1, borderColor: COLORS.accent, borderRadius: RADIUS.md, padding: 15, alignItems: 'center', marginTop: 4 },
  payAllText: { color: COLORS.accent, fontSize: 15, fontWeight: '700' },
})
