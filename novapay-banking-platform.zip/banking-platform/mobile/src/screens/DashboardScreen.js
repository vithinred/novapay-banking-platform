import React, { useState } from 'react'
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native'
import { useSafeAreaInsets } from 'react-native-safe-area-context'
import { COLORS, RADIUS } from '../styles/theme'

const ACCOUNTS = [
  { id: 1, name: 'Checking', number: '••• 4821', balance: 12480.50, change: +2.4, positive: true },
  { id: 2, name: 'Savings',  number: '••• 9034', balance: 38750.00, change: +0.8, positive: true },
  { id: 3, name: 'Invest',   number: '••• 1177', balance: 95200.75, change: -1.2, positive: false },
]

const TXS = [
  { id: 1, name: 'Netflix',         category: 'Subscriptions', amount: -15.99,  icon: '▶' },
  { id: 2, name: 'Direct Deposit',  category: 'Income',        amount: +3200.00, icon: '↓' },
  { id: 3, name: 'Whole Foods',     category: 'Groceries',     amount: -87.43,  icon: '⊛' },
  { id: 4, name: 'Savings Transfer',category: 'Transfer',      amount: -500.00, icon: '⇄' },
  { id: 5, name: 'Amazon',          category: 'Shopping',      amount: -134.00, icon: '◈' },
]

export default function DashboardScreen() {
  const insets = useSafeAreaInsets()
  const [activeAcc, setActiveAcc] = useState(0)

  return (
    <ScrollView
      style={[styles.container, { paddingTop: insets.top + 16 }]}
      showsVerticalScrollIndicator={false}
    >
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>Good morning, Vithin 👋</Text>
          <Text style={styles.subtitle}>Here's your financial overview</Text>
        </View>
        <View style={styles.notifBtn}>
          <Text style={{ fontSize: 16 }}>🔔</Text>
          <View style={styles.badge}><Text style={styles.badgeText}>3</Text></View>
        </View>
      </View>

      {/* Account cards - horizontal scroll */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.accScroll} contentContainerStyle={{ paddingHorizontal: 20, gap: 12 }}>
        {ACCOUNTS.map((acc, i) => (
          <TouchableOpacity
            key={acc.id}
            style={[styles.accCard, activeAcc === i && styles.accCardActive]}
            onPress={() => setActiveAcc(i)}
            activeOpacity={0.85}
          >
            <View style={styles.accTop}>
              <Text style={styles.accName}>{acc.name}</Text>
              <Text style={styles.accNumber}>{acc.number}</Text>
            </View>
            <Text style={styles.accBalance}>
              ${acc.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
            </Text>
            <Text style={[styles.accChange, { color: acc.positive ? COLORS.success : COLORS.danger }]}>
              {acc.positive ? '↑' : '↓'} {Math.abs(acc.change)}% this month
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <View style={styles.inner}>
        {/* Quick actions */}
        <View style={styles.quickGrid}>
          {['Send', 'Pay Bills', 'Add Card', 'History'].map(q => (
            <TouchableOpacity key={q} style={styles.quickBtn} activeOpacity={0.8}>
              <Text style={styles.quickText}>{q}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Spending bar */}
        <View style={styles.spendCard}>
          <View style={styles.spendTop}>
            <Text style={styles.spendTitle}>Monthly Spending</Text>
            <Text style={styles.spendAmt}>$2,847 / $4,000</Text>
          </View>
          <View style={styles.spendTrack}>
            <View style={[styles.spendFill, { width: '71%' }]} />
          </View>
          <Text style={styles.spendNote}>71% used · $1,153 remaining</Text>
        </View>

        {/* Transactions */}
        <Text style={styles.sectionTitle}>Recent Transactions</Text>
        {TXS.map(tx => (
          <View key={tx.id} style={styles.txRow}>
            <View style={styles.txIcon}><Text style={{ fontSize: 14 }}>{tx.icon}</Text></View>
            <View style={styles.txInfo}>
              <Text style={styles.txName}>{tx.name}</Text>
              <Text style={styles.txCat}>{tx.category}</Text>
            </View>
            <Text style={[styles.txAmt, { color: tx.amount > 0 ? COLORS.success : COLORS.textPrimary }]}>
              {tx.amount > 0 ? '+' : ''}${Math.abs(tx.amount).toFixed(2)}
            </Text>
          </View>
        ))}
      </View>
    </ScrollView>
  )
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.bgBase },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', paddingHorizontal: 20, marginBottom: 20 },
  greeting: { fontSize: 22, fontWeight: '700', color: COLORS.textPrimary },
  subtitle: { fontSize: 13, color: COLORS.textMuted, marginTop: 3 },
  notifBtn: { width: 40, height: 40, backgroundColor: COLORS.bgCard, borderRadius: 12, borderWidth: 1, borderColor: COLORS.border, alignItems: 'center', justifyContent: 'center' },
  badge: { position: 'absolute', top: 6, right: 6, width: 14, height: 14, borderRadius: 7, backgroundColor: COLORS.accent, alignItems: 'center', justifyContent: 'center' },
  badgeText: { fontSize: 8, fontWeight: '700', color: COLORS.bgBase },

  accScroll: { marginBottom: 24 },
  accCard: { width: 200, backgroundColor: COLORS.bgCard, borderRadius: RADIUS.lg, padding: 18, borderWidth: 1, borderColor: COLORS.border },
  accCardActive: { borderColor: COLORS.accent, backgroundColor: '#0d1f38' },
  accTop: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 12 },
  accName: { fontSize: 11, fontWeight: '700', color: COLORS.textSecondary, textTransform: 'uppercase', letterSpacing: 0.7 },
  accNumber: { fontSize: 10, color: COLORS.textMuted },
  accBalance: { fontSize: 20, fontWeight: '700', color: COLORS.textPrimary, marginBottom: 6 },
  accChange: { fontSize: 11, fontWeight: '500' },

  inner: { paddingHorizontal: 20, paddingBottom: 32, gap: 20 },

  quickGrid: { flexDirection: 'row', gap: 10 },
  quickBtn: { flex: 1, backgroundColor: COLORS.bgCard, borderRadius: RADIUS.md, padding: 12, alignItems: 'center', borderWidth: 1, borderColor: COLORS.border },
  quickText: { fontSize: 11, fontWeight: '600', color: COLORS.textSecondary },

  spendCard: { backgroundColor: COLORS.bgCard, borderRadius: RADIUS.lg, padding: 18, borderWidth: 1, borderColor: COLORS.border, gap: 10 },
  spendTop: { flexDirection: 'row', justifyContent: 'space-between' },
  spendTitle: { fontSize: 14, fontWeight: '600', color: COLORS.textPrimary },
  spendAmt: { fontSize: 13, color: COLORS.textSecondary },
  spendTrack: { height: 8, backgroundColor: COLORS.bgElevated, borderRadius: 4, overflow: 'hidden' },
  spendFill: { height: '100%', borderRadius: 4, backgroundColor: COLORS.accent },
  spendNote: { fontSize: 11, color: COLORS.textMuted },

  sectionTitle: { fontSize: 17, fontWeight: '700', color: COLORS.textPrimary },

  txRow: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: COLORS.bgCard, borderRadius: RADIUS.md, padding: 14, borderWidth: 1, borderColor: COLORS.border },
  txIcon: { width: 36, height: 36, backgroundColor: COLORS.bgElevated, borderRadius: 9, alignItems: 'center', justifyContent: 'center' },
  txInfo: { flex: 1, gap: 3 },
  txName: { fontSize: 14, fontWeight: '500', color: COLORS.textPrimary },
  txCat: { fontSize: 11, color: COLORS.textMuted },
  txAmt: { fontSize: 14, fontWeight: '600' },
})
