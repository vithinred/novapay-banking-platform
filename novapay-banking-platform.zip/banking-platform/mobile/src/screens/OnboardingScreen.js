import React, { useState, useRef } from 'react'
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, ScrollView, Dimensions, Animated
} from 'react-native'
import { useSafeAreaInsets } from 'react-native-safe-area-context'
import { COLORS, RADIUS } from '../styles/theme'

const { width } = Dimensions.get('window')
const STEPS = ['Account', 'Profile', 'Verify']

export default function OnboardingScreen({ onComplete }) {
  const insets = useSafeAreaInsets()
  const [step, setStep] = useState(0)
  const [form, setForm] = useState({ email: '', password: '', firstName: '', lastName: '', phone: '', dob: '', ssn: '' })
  const fadeAnim = useRef(new Animated.Value(1)).current

  const update = (k, v) => setForm(f => ({ ...f, [k]: v }))

  const next = () => {
    Animated.sequence([
      Animated.timing(fadeAnim, { toValue: 0, duration: 120, useNativeDriver: true }),
      Animated.timing(fadeAnim, { toValue: 1, duration: 220, useNativeDriver: true }),
    ]).start()
    if (step < STEPS.length - 1) setStep(s => s + 1)
    else onComplete()
  }

  return (
    <ScrollView
      style={[styles.container, { paddingTop: insets.top + 20 }]}
      contentContainerStyle={styles.content}
      keyboardShouldPersistTaps="handled"
    >
      {/* Brand */}
      <View style={styles.brand}>
        <View style={styles.brandMark}><Text style={styles.brandLetter}>N</Text></View>
        <Text style={styles.brandName}>NovaPay</Text>
      </View>

      {/* Step dots */}
      <View style={styles.stepRow}>
        {STEPS.map((s, i) => (
          <View key={s} style={styles.stepItem}>
            <View style={[styles.stepDot, i === step && styles.stepDotActive, i < step && styles.stepDotDone]}>
              <Text style={[styles.stepNum, (i === step || i < step) && styles.stepNumActive]}>
                {i < step ? '✓' : i + 1}
              </Text>
            </View>
            <Text style={[styles.stepLabel, i === step && styles.stepLabelActive]}>{s}</Text>
          </View>
        ))}
      </View>

      <Animated.View style={[styles.form, { opacity: fadeAnim }]}>
        <Text style={styles.formTitle}>{
          step === 0 ? 'Create your account' :
          step === 1 ? 'Tell us about yourself' :
          'Verify your identity'
        }</Text>

        {step === 0 && (
          <>
            <Field label="Email address" value={form.email} onChangeText={v => update('email', v)} placeholder="you@example.com" keyboardType="email-address" />
            <Field label="Password" value={form.password} onChangeText={v => update('password', v)} placeholder="Min. 8 characters" secureTextEntry />
          </>
        )}
        {step === 1 && (
          <>
            <View style={styles.row}>
              <View style={{ flex: 1 }}>
                <Field label="First name" value={form.firstName} onChangeText={v => update('firstName', v)} placeholder="Vithin" />
              </View>
              <View style={{ flex: 1 }}>
                <Field label="Last name" value={form.lastName} onChangeText={v => update('lastName', v)} placeholder="Reddy" />
              </View>
            </View>
            <Field label="Phone" value={form.phone} onChangeText={v => update('phone', v)} placeholder="+1 (682) 000-0000" keyboardType="phone-pad" />
          </>
        )}
        {step === 2 && (
          <>
            <Field label="Date of birth" value={form.dob} onChangeText={v => update('dob', v)} placeholder="MM / DD / YYYY" />
            <Field label="Last 4 of SSN" value={form.ssn} onChangeText={v => update('ssn', v)} placeholder="••••" secureTextEntry maxLength={4} keyboardType="numeric" />
            <View style={styles.secureNote}>
              <Text style={styles.secureText}>🔒  Encrypted with 256-bit AES</Text>
            </View>
          </>
        )}
      </Animated.View>

      <TouchableOpacity style={styles.cta} onPress={next} activeOpacity={0.85}>
        <Text style={styles.ctaText}>
          {step === STEPS.length - 1 ? 'Open My Account →' : 'Continue →'}
        </Text>
      </TouchableOpacity>

      <View style={styles.features}>
        {['Zero-fee transfers', 'Instant notifications', 'FDIC insured'].map(f => (
          <Text key={f} style={styles.featureItem}>✓  {f}</Text>
        ))}
      </View>
    </ScrollView>
  )
}

function Field({ label, ...props }) {
  const [focused, setFocused] = useState(false)
  return (
    <View style={styles.fieldWrap}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <TextInput
        style={[styles.fieldInput, focused && styles.fieldFocused]}
        placeholderTextColor={COLORS.textMuted}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        autoCapitalize="none"
        {...props}
      />
    </View>
  )
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.bgBase },
  content: { padding: 24, paddingBottom: 48, gap: 28 },

  brand: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  brandMark: { width: 38, height: 38, borderRadius: 10, backgroundColor: COLORS.accent, alignItems: 'center', justifyContent: 'center' },
  brandLetter: { color: COLORS.bgBase, fontSize: 20, fontWeight: '800' },
  brandName: { color: COLORS.textPrimary, fontSize: 20, fontWeight: '700' },

  stepRow: { flexDirection: 'row', gap: 0, alignItems: 'center' },
  stepItem: { flex: 1, alignItems: 'center', gap: 6 },
  stepDot: { width: 28, height: 28, borderRadius: 14, backgroundColor: COLORS.bgElevated, borderWidth: 1, borderColor: COLORS.border, alignItems: 'center', justifyContent: 'center' },
  stepDotActive: { borderColor: COLORS.accent, backgroundColor: COLORS.accentDim },
  stepDotDone: { backgroundColor: COLORS.accent, borderColor: COLORS.accent },
  stepNum: { fontSize: 11, fontWeight: '600', color: COLORS.textMuted },
  stepNumActive: { color: COLORS.bgBase },
  stepLabel: { fontSize: 10, color: COLORS.textMuted },
  stepLabelActive: { color: COLORS.accent },

  form: { gap: 16 },
  formTitle: { fontSize: 24, fontWeight: '700', color: COLORS.textPrimary, marginBottom: 4 },
  row: { flexDirection: 'row', gap: 12 },

  fieldWrap: { gap: 6 },
  fieldLabel: { fontSize: 12, fontWeight: '600', color: COLORS.textSecondary, textTransform: 'uppercase', letterSpacing: 0.7 },
  fieldInput: { backgroundColor: COLORS.bgInput, borderWidth: 1, borderColor: COLORS.border, borderRadius: RADIUS.sm, padding: 13, color: COLORS.textPrimary, fontSize: 14 },
  fieldFocused: { borderColor: COLORS.accent },

  secureNote: { backgroundColor: COLORS.bgElevated, borderRadius: RADIUS.sm, padding: 12, borderWidth: 1, borderColor: COLORS.border },
  secureText: { fontSize: 12, color: COLORS.textMuted },

  cta: { backgroundColor: COLORS.accent, borderRadius: RADIUS.md, padding: 16, alignItems: 'center', shadowColor: COLORS.accent, shadowOpacity: 0.4, shadowRadius: 16, shadowOffset: { width: 0, height: 6 } },
  ctaText: { color: COLORS.bgBase, fontSize: 16, fontWeight: '700' },

  features: { gap: 10 },
  featureItem: { color: COLORS.textSecondary, fontSize: 13 },
})
