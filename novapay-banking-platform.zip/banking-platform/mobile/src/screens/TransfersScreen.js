import React, { useState } from 'react'
import { View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet } from 'react-native'
import { useSafeAreaInsets } from 'react-native-safe-area-context'
import { COLORS, RADIUS } from '../styles/theme'

const ACCOUNTS = [
  { id: 'chk', label: 'Checking', balance: '$12,480.50' },
  { id: 'sav', label: 'Savings',  balance: '$38,750.00' },
]

const RECIPIENTS = [
  { id: 1, name: 'Sarah Johnson', bank: 'Chase',        initials: 'SJ', color: '#7B5CF5' },
  { id: 2, name: 'Rahul Mehta',   bank: 'Wells Fargo',  initials: 'RM', color: '#00B89F' },
  { id: 3, name: 'Kyoto Wave',    bank: 'Bank of Amer', initials: 'KW', color: '#FF6B6B' },
  { id: 4, name: 'Add New',       bank: '',             initials: '+',  color: COLORS.bgElevated },
]

export default function TransfersScreen() {
  const insets = useSafeAreaInsets()
  const [from,   setFrom]   = useState('chk')
  const [to,     setTo]     = useState(null)
  const [amount, setAmount] = useState('')
  const [note,   setNote]   = useState('')
  const [sent,   setSent]   = useState(false)

  const handleSend = () => {
    if (!to || !amount) return
    setSent(true)
    setTimeout(() => { setSent(false); setAmount(''); setNote(''); setTo(null) }, 2500)
  }

  return (
    <ScrollView
      style={[styles.container, { paddingTop: insets.top + 16 }]}
      contentContainerStyle={styles.content}
      keyboardShouldPersistTaps="handled"
    >
      <Text style={styles.title}>Send Money</Text>

      {/* From */}
      <View style={styles.section}>
        <Text style={styles.label}>From account</Text>
        <View style={styles.accRow}>
          {ACCOUNTS.map(acc => (
            <TouchableOpacity
              key={acc.id}
              style={[styles.accBtn, from === acc.id && styles.accBtnActive]}
              onPress={() => setFrom(acc.id)}
            >
              <Text style={styles.accBtnName}>{acc.label}</Text>
              <Text style={styles.accBtnBal}>{acc.balance}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Recipients */}
      <View style={styles.section}>
        <Text style={styles.label}>Recipient</Text>
        <View style={styles.recipGrid}>
          {RECIPIENTS.map(r => (
            <TouchableOpacity
              key={r.id}
              style={[styles.recipBtn, to === r.id && styles.recipActive]}
              onPress={() => setTo(r.id)}
              activeOpacity={0.8}
            >
              <View style={[styles.recipAvatar, { backgroundColor: r.color }]}>
                <Text style={styles.recipInitials}>{r.initials}</Text>
              </View>
              <Text style={styles.recipName} numberOfLines={1}>{r.name}</Text>
              <Text style={styles.recipBank} numberOfLines={1}>{r.bank}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Amount */}
      <View style={styles.section}>
        <Text style={styles.label}>Amount</Text>
        <View style={styles.amountRow}>
          <Text style={styles.currency}>$</Text>
          <TextInput
            style={styles.amountInput}
            value={amount}
            onChangeText={setAmount}
            placeholder="0.00"
            placeholderTextColor={COLORS.textMuted}
            keyboardType="decimal-pad"
          />
        </View>
      </View>

      {/* Note */}
      <View style={styles.section}>
        <Text style={styles.label}>Note (optional)</Text>
        <TextInput
          style={styles.noteInput}
          value={note}
          onChangeText={setNote}
          placeholder="What's it for?"
          placeholderTextColor={COLORS.textMuted}
        />
      </View>

      {/* Preview pill */}
      {(to || amount) && (
        <View style={styles.preview}>
          <View style={styles.previewItem}><Text style={styles.previewKey}>To</Text><Text style={styles.previewVal}>{RECIPIENTS.find(r => r.id === to)?.name || '—'}</Text></View>
          <View style={styles.previewDivider} />
          <View style={styles.previewItem}><Text style={styles.previewKey}>Fee</Text><Text style={[styles.previewVal, { color: COLORS.success }]}>Free</Text></View>
          <View style={styles.previewDivider} />
          <View style={styles.previewItem}><Text style={styles.previewKey}>Arrives</Text><Text style={[styles.previewVal, { color: COLORS.success }]}>Instant</Text></View>
        </View>
      )}

      <TouchableOpacity
        style={[styles.sendBtn, sent && styles.sentBtn, (!to || !amount) && styles.sendBtnDisabled]}
        onPress={handleSend}
        activeOpacity={0.85}
      >
        <Text style={styles.sendBtnText}>{sent ? '✓  Transfer Sent!' : 'Send Transfer →'}</Text>
      </TouchableOpacity>
    </ScrollView>
  )
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.bgBase },
  content: { padding: 20, paddingBottom: 40, gap: 24 },
  title: { fontSize: 26, fontWeight: '700', color: COLORS.textPrimary },

  section: { gap: 10 },
  label: { fontSize: 11, fontWeight: '700', color: COLORS.textSecondary, textTransform: 'uppercase', letterSpacing: 0.8 },

  accRow: { flexDirection: 'row', gap: 12 },
  accBtn: { flex: 1, backgroundColor: COLORS.bgCard, borderRadius: RADIUS.md, padding: 14, borderWidth: 1, borderColor: COLORS.border, gap: 4 },
  accBtnActive: { borderColor: COLORS.accent, backgroundColor: COLORS.accentDim },
  accBtnName: { fontSize: 13, fontWeight: '600', color: COLORS.textPrimary },
  accBtnBal: { fontSize: 12, color: COLORS.textSecondary },

  recipGrid: { flexDirection: 'row', gap: 10 },
  recipBtn: { flex: 1, backgroundColor: COLORS.bgCard, borderRadius: RADIUS.md, padding: 12, borderWidth: 1, borderColor: COLORS.border, alignItems: 'center', gap: 6 },
  recipActive: { borderColor: COLORS.accent, backgroundColor: COLORS.accentDim },
  recipAvatar: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  recipInitials: { fontSize: 13, fontWeight: '700', color: 'white' },
  recipName: { fontSize: 10, fontWeight: '600', color: COLORS.textPrimary, textAlign: 'center' },
  recipBank: { fontSize: 9, color: COLORS.textMuted, textAlign: 'center' },

  amountRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.bgCard, borderRadius: RADIUS.md, borderWidth: 1, borderColor: COLORS.border, paddingHorizontal: 16 },
  currency: { fontSize: 26, color: COLORS.textMuted, fontWeight: '700', marginRight: 6 },
  amountInput: { flex: 1, fontSize: 32, fontWeight: '700', color: COLORS.textPrimary, paddingVertical: 14 },

  noteInput: { backgroundColor: COLORS.bgCard, borderRadius: RADIUS.md, borderWidth: 1, borderColor: COLORS.border, padding: 13, color: COLORS.textPrimary, fontSize: 14 },

  preview: { flexDirection: 'row', backgroundColor: COLORS.bgCard, borderRadius: RADIUS.md, borderWidth: 1, borderColor: COLORS.border, padding: 14 },
  previewItem: { flex: 1, alignItems: 'center', gap: 4 },
  previewKey: { fontSize: 10, color: COLORS.textMuted, textTransform: 'uppercase', letterSpacing: 0.5 },
  previewVal: { fontSize: 13, fontWeight: '600', color: COLORS.textPrimary },
  previewDivider: { width: 1, backgroundColor: COLORS.border, marginHorizontal: 4 },

  sendBtn: { backgroundColor: COLORS.accent, borderRadius: RADIUS.md, padding: 16, alignItems: 'center', shadowColor: COLORS.accent, shadowOpacity: 0.4, shadowRadius: 16, shadowOffset: { width: 0, height: 6 } },
  sentBtn: { backgroundColor: COLORS.success },
  sendBtnDisabled: { opacity: 0.4 },
  sendBtnText: { color: COLORS.bgBase, fontSize: 16, fontWeight: '700' },
})
