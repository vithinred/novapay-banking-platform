export const COLORS = {
  bgBase:     '#0A0F1E',
  bgCard:     '#111827',
  bgElevated: '#1A2235',
  bgInput:    '#151D2E',
  accent:     '#00D4FF',
  accentDim:  'rgba(0,212,255,0.12)',
  textPrimary:'#F0F4FF',
  textSecondary:'#8B9DC3',
  textMuted:  '#4A5A7A',
  success:    '#00E5A0',
  warning:    '#FFB547',
  danger:     '#FF5C7A',
  border:     'rgba(255,255,255,0.07)',
}

export const FONTS = {
  displayBold:   { fontWeight: '800' },
  displaySemi:   { fontWeight: '700' },
  bodyMedium:    { fontWeight: '500' },
  bodyRegular:   { fontWeight: '400' },
}

export const RADIUS = {
  sm: 8,
  md: 14,
  lg: 20,
  xl: 28,
}
