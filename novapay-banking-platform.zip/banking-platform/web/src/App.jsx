import { Routes, Route, Navigate } from 'react-router-dom'
import Onboarding from './screens/Onboarding.jsx'
import Dashboard from './screens/Dashboard.jsx'
import Transfers from './screens/Transfers.jsx'
import BillPay from './screens/BillPay.jsx'
import AppShell from './components/AppShell.jsx'

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Onboarding />} />
      <Route element={<AppShell />}>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/transfers" element={<Transfers />} />
        <Route path="/billpay" element={<BillPay />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
