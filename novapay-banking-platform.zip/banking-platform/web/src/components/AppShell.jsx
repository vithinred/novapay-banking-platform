import { Outlet, NavLink } from 'react-router-dom'
import styles from './AppShell.module.css'

const NAV = [
  { to: '/dashboard', label: 'Dashboard', icon: '⬡' },
  { to: '/transfers', label: 'Transfers', icon: '⇄' },
  { to: '/billpay',   label: 'Bill Pay',  icon: '◈' },
]

export default function AppShell() {
  return (
    <div className={styles.shell}>
      <aside className={styles.sidebar}>
        <div className={styles.logo}>
          <span className={styles.logoMark}>N</span>
          <span className={styles.logoText}>NovaPay</span>
        </div>
        <nav className={styles.nav}>
          {NAV.map(({ to, label, icon }) => (
            <NavLink
              key={to}
              to={to}
              className={({ isActive }) =>
                `${styles.navItem} ${isActive ? styles.active : ''}`
              }
            >
              <span className={styles.navIcon}>{icon}</span>
              <span>{label}</span>
            </NavLink>
          ))}
        </nav>
        <div className={styles.userChip}>
          <div className={styles.avatar}>VR</div>
          <div>
            <div className={styles.userName}>Vithin Reddy</div>
            <div className={styles.userRole}>Personal · Pro</div>
          </div>
        </div>
      </aside>
      <main className={styles.content}>
        <Outlet />
      </main>
    </div>
  )
}
