import { useState } from 'react'
import styles from './BillPay.module.css'

const BILLERS = [
  { id: 1, name: 'AT&T Wireless', category: 'Utilities', due: 'Feb 3', amount: 89.99, icon: '📡', status: 'due' },
  { id: 2, name: 'Electricity – TXU', category: 'Utilities', due: 'Feb 7', amount: 134.50, icon: '⚡', status: 'due' },
  { id: 3, name: 'Rent – Oakwood Apts', category: 'Housing', due: 'Feb 1', amount: 1450.00, icon: '🏠', status: 'scheduled' },
  { id: 4, name: 'Chase Visa', category: 'Credit Card', due: 'Feb 15', amount: 342.00, icon: '💳', status: 'pending' },
  { id: 5, name: 'Spotify', category: 'Subscription', due: 'Feb 18', amount: 9.99, icon: '♪', status: 'autopay' },
  { id: 6, name: 'Internet – Xfinity', category: 'Utilities', due: 'Feb 20', amount: 65.00, icon: '◈', status: 'autopay' },
]

const STATUS_META = {
  due:       { label: 'Due Soon',  color: '#FFB547' },
  scheduled: { label: 'Scheduled', color: '#00D4FF' },
  pending:   { label: 'Pending',   color: '#8B9DC3' },
  autopay:   { label: 'AutoPay ✓', color: '#00E5A0' },
}

export default function BillPay() {
  const [selected, setSelected] = useState(null)
  const [paid, setPaid]         = useState([])
  const [filter, setFilter]     = useState('all')

  const handlePay = (id) => {
    setPaid(p => [...p, id])
    setSelected(null)
  }

  const visible = BILLERS.filter(b => {
    if (filter === 'all') return true
    if (filter === 'due') return b.status === 'due'
    if (filter === 'auto') return b.status === 'autopay'
    return true
  })

  const totalDue = BILLERS.filter(b => b.status === 'due' && !paid.includes(b.id)).reduce((s, b) => s + b.amount, 0)

  return (
    <div className={`${styles.page} page-enter`}>
      <div className={styles.topRow}>
        <h1 className={styles.title}>Bill Pay</h1>
        <div className={styles.totalDue}>
          <span className={styles.totalLabel}>Outstanding</span>
          <span className={styles.totalAmount}>${totalDue.toFixed(2)}</span>
        </div>
      </div>

      <div className={styles.filters}>
        {['all', 'due', 'auto'].map(f => (
          <button key={f} className={`${styles.filterBtn} ${filter === f ? styles.filterActive : ''}`} onClick={() => setFilter(f)}>
            {f === 'all' ? 'All Bills' : f === 'due' ? 'Due Soon' : 'AutoPay'}
          </button>
        ))}
      </div>

      <div className={styles.billList}>
        {visible.map(bill => {
          const isPaid = paid.includes(bill.id)
          const meta = STATUS_META[bill.status]
          return (
            <div
              key={bill.id}
              className={`${styles.billRow} ${isPaid ? styles.billPaid : ''} ${selected === bill.id ? styles.billSelected : ''}`}
              onClick={() => !isPaid && setSelected(selected === bill.id ? null : bill.id)}
            >
              <div className={styles.billIcon}>{bill.icon}</div>
              <div className={styles.billInfo}>
                <span className={styles.billName}>{bill.name}</span>
                <span className={styles.billMeta}>{bill.category} · Due {bill.due}</span>
              </div>
              <div className={styles.billRight}>
                <span className={styles.billAmount}>${bill.amount.toFixed(2)}</span>
                <span className={styles.billStatus} style={{ color: isPaid ? '#00E5A0' : meta.color }}>
                  {isPaid ? 'Paid ✓' : meta.label}
                </span>
              </div>

              {selected === bill.id && !isPaid && (
                <div className={styles.payPanel} onClick={e => e.stopPropagation()}>
                  <div className={styles.payDetail}>
                    <span>Pay ${bill.amount.toFixed(2)} to</span>
                    <strong>{bill.name}</strong>
                  </div>
                  <div className={styles.payActions}>
                    <button className={styles.payNowBtn} onClick={() => handlePay(bill.id)}>Pay Now</button>
                    <button className={styles.scheduleBtn}>Schedule</button>
                  </div>
                </div>
              )}
            </div>
          )
        })}
      </div>

      <button className={styles.payAllBtn} onClick={() => visible.filter(b => b.status === 'due').forEach(b => handlePay(b.id))}>
        Pay All Due Bills
      </button>
    </div>
  )
}
