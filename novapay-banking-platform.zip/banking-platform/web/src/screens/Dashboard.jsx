import { useState } from 'react'
import styles from './Dashboard.module.css'

const ACCOUNTS = [
  { id: 1, name: 'Checking', number: '••• 4821', balance: 12480.50, change: +2.4 },
  { id: 2, name: 'Savings', number: '••• 9034', balance: 38750.00, change: +0.8 },
  { id: 3, name: 'Investment', number: '••• 1177', balance: 95200.75, change: -1.2 },
]

const TRANSACTIONS = [
  { id: 1, name: 'Netflix', category: 'Subscriptions', amount: -15.99, date: 'Today', icon: '▶' },
  { id: 2, name: 'Direct Deposit', category: 'Income', amount: +3200.00, date: 'Yesterday', icon: '↓' },
  { id: 3, name: 'Whole Foods', category: 'Groceries', amount: -87.43, date: 'Jan 28', icon: '⊛' },
  { id: 4, name: 'Transfer to Savings', category: 'Transfer', amount: -500.00, date: 'Jan 27', icon: '⇄' },
  { id: 5, name: 'Spotify', category: 'Subscriptions', amount: -9.99, date: 'Jan 26', icon: '♪' },
  { id: 6, name: 'Amazon', category: 'Shopping', amount: -134.00, date: 'Jan 25', icon: '◈' },
]

const QUICK = ['Send Money', 'Pay Bills', 'Add Card', 'Statements']

export default function Dashboard() {
  const [activeAccount, setActiveAccount] = useState(0)

  return (
    <div className={`${styles.page} page-enter`}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.greeting}>Good morning, Vithin 👋</h1>
          <p className={styles.date}>Thursday, January 30, 2025</p>
        </div>
        <div className={styles.notifBtn}>
          <span>🔔</span>
          <span className={styles.badge}>3</span>
        </div>
      </div>

      {/* Account Cards */}
      <div className={styles.accountScroll}>
        {ACCOUNTS.map((acc, i) => (
          <div
            key={acc.id}
            className={`${styles.accountCard} ${activeAccount === i ? styles.accountActive : ''}`}
            onClick={() => setActiveAccount(i)}
          >
            <div className={styles.accTop}>
              <span className={styles.accName}>{acc.name}</span>
              <span className={styles.accNumber}>{acc.number}</span>
            </div>
            <div className={styles.accBalance}>${acc.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}</div>
            <div className={`${styles.accChange} ${acc.change >= 0 ? styles.positive : styles.negative}`}>
              {acc.change >= 0 ? '↑' : '↓'} {Math.abs(acc.change)}% this month
            </div>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className={styles.quickGrid}>
        {QUICK.map(q => (
          <button key={q} className={styles.quickBtn}>{q}</button>
        ))}
      </div>

      {/* Spending Bar */}
      <div className={styles.spendCard}>
        <div className={styles.spendHeader}>
          <span className={styles.spendTitle}>Monthly Spending</span>
          <span className={styles.spendAmount}>$2,847 / $4,000</span>
        </div>
        <div className={styles.spendBar}>
          <div className={styles.spendFill} style={{ width: '71%' }} />
        </div>
        <div className={styles.spendNote}>71% of monthly budget used · $1,153 remaining</div>
      </div>

      {/* Transactions */}
      <div className={styles.txSection}>
        <div className={styles.txHeader}>
          <span className={styles.txTitle}>Recent Transactions</span>
          <button className={styles.txViewAll}>View all</button>
        </div>
        {TRANSACTIONS.map(tx => (
          <div key={tx.id} className={styles.txRow}>
            <div className={styles.txIcon}>{tx.icon}</div>
            <div className={styles.txInfo}>
              <span className={styles.txName}>{tx.name}</span>
              <span className={styles.txCategory}>{tx.category} · {tx.date}</span>
            </div>
            <span className={`${styles.txAmount} ${tx.amount > 0 ? styles.credit : styles.debit}`}>
              {tx.amount > 0 ? '+' : ''}${Math.abs(tx.amount).toFixed(2)}
            </span>
          </div>
        ))}
      </div>
    </div>
  )
}
