import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import styles from './Onboarding.module.css'

const STEPS = ['Create Account', 'Personal Info', 'Verify Identity']

export default function Onboarding() {
  const navigate = useNavigate()
  const [step, setStep] = useState(0)
  const [form, setForm] = useState({
    email: '', password: '',
    firstName: '', lastName: '', phone: '',
    ssn: '', dob: ''
  })

  const update = (k, v) => setForm(f => ({ ...f, [k]: v }))
  const next = () => step < STEPS.length - 1 ? setStep(s => s + 1) : navigate('/dashboard')

  return (
    <div className={styles.page}>
      <div className={styles.left}>
        <div className={styles.brand}>
          <span className={styles.brandMark}>N</span>
          <span className={styles.brandName}>NovaPay</span>
        </div>
        <div className={styles.headline}>
          <h1>Banking built<br />for what's next.</h1>
          <p>Open your account in under 3 minutes. No paperwork, no branch visits.</p>
        </div>
        <div className={styles.features}>
          {['Zero-fee transfers', 'Instant notifications', 'AI-powered insights', 'FDIC insured up to $250K'].map(f => (
            <div key={f} className={styles.featureItem}>
              <span className={styles.check}>✓</span> {f}
            </div>
          ))}
        </div>
      </div>

      <div className={styles.right}>
        <div className={styles.card} key={step} style={{ animation: 'fadeUp 0.3s ease forwards' }}>
          <div className={styles.stepIndicator}>
            {STEPS.map((s, i) => (
              <div key={s} className={`${styles.stepDot} ${i === step ? styles.stepActive : ''} ${i < step ? styles.stepDone : ''}`}>
                <span className={styles.stepNum}>{i < step ? '✓' : i + 1}</span>
                <span className={styles.stepLabel}>{s}</span>
              </div>
            ))}
          </div>

          <h2 className={styles.formTitle}>{STEPS[step]}</h2>

          {step === 0 && (
            <div className={styles.fields}>
              <Field label="Email address" type="email" value={form.email} onChange={v => update('email', v)} placeholder="you@example.com" />
              <Field label="Password" type="password" value={form.password} onChange={v => update('password', v)} placeholder="Min. 8 characters" />
              <p className={styles.terms}>By continuing you agree to our <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a>.</p>
            </div>
          )}

          {step === 1 && (
            <div className={styles.fields}>
              <div className={styles.row}>
                <Field label="First name" value={form.firstName} onChange={v => update('firstName', v)} placeholder="Vithin" />
                <Field label="Last name" value={form.lastName} onChange={v => update('lastName', v)} placeholder="Reddy" />
              </div>
              <Field label="Phone number" type="tel" value={form.phone} onChange={v => update('phone', v)} placeholder="+1 (682) 000-0000" />
            </div>
          )}

          {step === 2 && (
            <div className={styles.fields}>
              <Field label="Date of birth" type="date" value={form.dob} onChange={v => update('dob', v)} />
              <Field label="Last 4 of SSN" type="password" value={form.ssn} onChange={v => update('ssn', v)} placeholder="••••" maxLength={4} />
              <div className={styles.secureNote}>
                <span>🔒</span> Your info is encrypted with 256-bit AES
              </div>
            </div>
          )}

          <button className={styles.cta} onClick={next}>
            {step === STEPS.length - 1 ? 'Open My Account →' : 'Continue →'}
          </button>
        </div>
      </div>
    </div>
  )
}

function Field({ label, value, onChange, ...props }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <label style={{ fontSize: 13, fontWeight: 500, color: 'var(--text-secondary)' }}>{label}</label>
      <input
        value={value}
        onChange={e => onChange(e.target.value)}
        style={{
          background: 'var(--bg-input)', border: '1px solid var(--border)',
          borderRadius: 'var(--radius-sm)', padding: '11px 14px',
          color: 'var(--text-primary)', fontSize: 14,
          outline: 'none', transition: 'border-color 0.2s'
        }}
        onFocus={e => e.target.style.borderColor = 'var(--accent)'}
        onBlur={e => e.target.style.borderColor = 'var(--border)'}
        {...props}
      />
    </div>
  )
}
