import { useState } from 'react'
import styles from './Transfers.module.css'

const ACCOUNTS = [
  { id: 'chk', label: 'Checking', balance: '$12,480.50' },
  { id: 'sav', label: 'Savings',  balance: '$38,750.00' },
]

const RECIPIENTS = [
  { id: 1, name: 'Sarah Johnson', bank: 'Chase Bank', initials: 'SJ', color: '#7B5CF5' },
  { id: 2, name: 'Rahul Mehta',   bank: 'Wells Fargo', initials: 'RM', color: '#00B89F' },
  { id: 3, name: 'Kyoto Wave Co', bank: 'Bank of America', initials: 'KW', color: '#FF6B6B' },
  { id: 4, name: 'Add New',       bank: '',             initials: '+',  color: '#2E3A52' },
]

export default function Transfers() {
  const [from, setFrom]   = useState('chk')
  const [to, setTo]       = useState(null)
  const [amount, setAmount] = useState('')
  const [note, setNote]   = useState('')
  const [sent, setSent]   = useState(false)

  const handleSend = () => {
    if (!to || !amount) return
    setSent(true)
    setTimeout(() => setSent(false), 3000)
    setAmount('')
    setNote('')
    setTo(null)
  }

  return (
    <div className={`${styles.page} page-enter`}>
      <h1 className={styles.title}>Send Money</h1>

      <div className={styles.grid}>
        <div className={styles.left}>
          {/* From */}
          <div className={styles.section}>
            <label className={styles.label}>From account</label>
            <div className={styles.accountPicker}>
              {ACCOUNTS.map(acc => (
                <button
                  key={acc.id}
                  className={`${styles.accBtn} ${from === acc.id ? styles.accBtnActive : ''}`}
                  onClick={() => setFrom(acc.id)}
                >
                  <span className={styles.accBtnName}>{acc.label}</span>
                  <span className={styles.accBtnBal}>{acc.balance}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Recipient */}
          <div className={styles.section}>
            <label className={styles.label}>Recipient</label>
            <div className={styles.recipientGrid}>
              {RECIPIENTS.map(r => (
                <button
                  key={r.id}
                  className={`${styles.recipBtn} ${to === r.id ? styles.recipActive : ''}`}
                  onClick={() => setTo(r.id)}
                >
                  <div className={styles.recipAvatar} style={{ background: r.color }}>{r.initials}</div>
                  <span className={styles.recipName}>{r.name}</span>
                  <span className={styles.recipBank}>{r.bank}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Amount */}
          <div className={styles.section}>
            <label className={styles.label}>Amount</label>
            <div className={styles.amountWrap}>
              <span className={styles.currency}>$</span>
              <input
                type="number"
                className={styles.amountInput}
                value={amount}
                onChange={e => setAmount(e.target.value)}
                placeholder="0.00"
              />
            </div>
          </div>

          {/* Note */}
          <div className={styles.section}>
            <label className={styles.label}>Note (optional)</label>
            <input
              type="text"
              className={styles.noteInput}
              value={note}
              onChange={e => setNote(e.target.value)}
              placeholder="What's it for?"
            />
          </div>

          <button
            className={`${styles.sendBtn} ${sent ? styles.sentBtn : ''}`}
            onClick={handleSend}
            disabled={!to || !amount}
          >
            {sent ? '✓ Transfer Sent!' : 'Send Transfer →'}
          </button>
        </div>

        {/* Preview */}
        <div className={styles.right}>
          <div className={styles.previewCard}>
            <div className={styles.previewLabel}>Transfer Preview</div>
            <div className={styles.previewAmount}>
              {amount ? `$${parseFloat(amount || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}` : '—'}
            </div>
            <div className={styles.previewRow}>
              <span>From</span>
              <span>{ACCOUNTS.find(a => a.id === from)?.label}</span>
            </div>
            <div className={styles.previewRow}>
              <span>To</span>
              <span>{RECIPIENTS.find(r => r.id === to)?.name || '—'}</span>
            </div>
            <div className={styles.previewRow}>
              <span>Arrives</span>
              <span className={styles.instant}>Instant</span>
            </div>
            <div className={styles.previewRow}>
              <span>Fee</span>
              <span className={styles.free}>Free</span>
            </div>
            {note && (
              <div className={styles.previewNote}>"{note}"</div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
